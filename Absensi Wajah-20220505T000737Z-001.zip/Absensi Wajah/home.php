<?php if(empty($p)) { header("Location: index.php?p=home"); die(); } ?>

<?php slideshow();?>

  